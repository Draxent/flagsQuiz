# Flags Quiz

Introduction to Flutter with a flags quiz game

## Links

- [Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Flutter Widget of the Week](https://www.youtube.com/watch?v=JSqUZFkRLr8&list=PLjxrf2q8roU23XGwz3Km7sQZFTdB996iG&ab_channel=Flutter)
